# Hermes Desktop — Traducción al Español (v3 - completa)

## Contenido
- es.ts — Traducción completa: UI + fieldLabels + fieldDescriptions (~2480 líneas)
- types.ts — Tipo Locale con "es" agregado
- languages.ts — Dropdown + aliases (es-MX, es-AR, es-VE, es-CO, es-CL, es-PE)
- catalog.ts — Registro del locale español

## Qué cubre
- Sidebar, menús, botones, tooltips
- Todas las pestañas de configuración (Modelo, Chat, Seguridad, Voz, etc.)
- Labels y descripciones de todos los campos de config
- Notificaciones, mensajes de error, diálogos
- Compositor, barra lateral, agentes, cron, artefactos

## Cómo aplicar
1. Copiar los .ts a: apps/desktop/src/i18n/
2. Reconstruir: npx vite build + repack asar
3. Reiniciar Hermes Desktop → Settings → Appearance → Language → Español
